import "./navBar.css";

function NavBar() {
  return (
    <div className="nav">
      <h3>Menu will be here!</h3>
    </div>
  );
}

export default NavBar;
